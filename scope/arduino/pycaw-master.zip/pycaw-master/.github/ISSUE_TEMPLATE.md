Make sure to give enough information to help debugging your issue.
Here are some hints:

- current requirements (pip freeze)
- OS version
- architecture
- Python version
- pycaw version
- project files
- exact stacktrace / accurate error message
- and so on
