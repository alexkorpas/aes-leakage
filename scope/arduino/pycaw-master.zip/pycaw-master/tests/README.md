# Tests

## Run all tests

Using Python unit testing framework:

    python -m unittest discover

Using Tox:

    tox
